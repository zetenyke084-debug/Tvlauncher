package hu.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    // ---- BEÁLLÍTÁSOK: ide írd át a városod koordinátáit ----
    private val LAT = 47.9025   // Eger
    private val LON = 20.3772
    // --------------------------------------------------------

    data class AppDef(val key: String, val label: String, val pkgs: List<String>, val logo: Int? = null)

    private val apps = listOf(
        AppDef("Netflix", "Netflix", listOf("com.netflix.ninja")),
        AppDef("YouTube", "YouTube", listOf("com.google.android.youtube.tv")),
        AppDef("Apple Music", "Apple Music", listOf("com.apple.android.music"), R.drawable.logo_apple_music),
        AppDef("Apple TV", "Apple TV", listOf("com.apple.atve.androidtv.appletv"), R.drawable.logo_apple_tv),
        AppDef("Disney", "Disney+", listOf("com.disney.disneyplus")),
        AppDef("SkyShowtime", "SkyShowtime", listOf())
    )

    // ---------- Háttér jelenetek (hegy, óceán, sivatag...) ----------
    // pts: "x,y x,y ..." a képernyő arányában (0..1). front=true: az óra FÖLÖTT rajzolódik (mélység effekt)
    class Layer(val front: Boolean, val color: Int, val smooth: Boolean, val pts: FloatArray)
    class Scene(
        val name: String, val sky: IntArray, val layers: List<Layer>,
        val trees: List<FloatArray> = emptyList(), val treeColor: Int = 0,
        val stars: Boolean = false, val orb: FloatArray? = null, val orbColor: Int = 0
    )

    private fun P(s: String) = s.trim().split(Regex("[ ,]+")).map { it.toFloat() }.toFloatArray()
    private fun L(front: Boolean, color: Long, smooth: Boolean, pts: String) = Layer(front, color.toInt(), smooth, P(pts))
    private fun sky(a: Long, b: Long, c: Long) = intArrayOf(a.toInt(), b.toInt(), c.toInt())
    private fun zig(base: Float, amp: Float, n: Int): FloatArray {
        val a = FloatArray((n + 1) * 2)
        for (i in 0..n) {
            a[i * 2] = i.toFloat() / n
            a[i * 2 + 1] = base - (if (i % 2 == 0) amp * (0.55f + 0.45f * Math.sin(i * 1.9).toFloat()) else 0f)
        }
        return a
    }

    private fun buildScenes(): List<Scene> {
        val farR = "0,0.60 0.10,0.50 0.20,0.57 0.33,0.45 0.47,0.58 0.60,0.47 0.73,0.56 0.86,0.46 1,0.54"
        val midR = "0,0.70 0.12,0.60 0.25,0.68 0.40,0.56 0.55,0.66 0.70,0.58 0.85,0.66 1,0.60"
        // a fő csúcs (0.60, 0.31) belóg az óra aljába
        val peak = "0,0.80 0.12,0.66 0.24,0.58 0.36,0.52 0.48,0.43 0.60,0.31 0.69,0.41 0.76,0.38 0.90,0.56 1,0.64"
        val pines = listOf(
            floatArrayOf(0.03f, 0.93f, 0.30f), floatArrayOf(0.09f, 0.96f, 0.24f), floatArrayOf(0.15f, 0.94f, 0.17f),
            floatArrayOf(0.82f, 0.96f, 0.15f), floatArrayOf(0.88f, 0.94f, 0.22f), floatArrayOf(0.94f, 0.97f, 0.30f),
            floatArrayOf(1.0f, 0.95f, 0.26f)
        )
        return listOf(
            Scene("Hegyek", sky(0xFF1A2347, 0xFF5B4A82, 0xFFE9A07A),
                listOf(L(false, 0xFF8A78A8, false, farR), L(false, 0xFF54497F, false, midR), L(true, 0xFF241F45, false, peak)),
                pines, 0xFF120F28.toInt()),
            Scene("Naplemente", sky(0xFF2A1B3D, 0xFFB5476B, 0xFFFFB36B),
                listOf(L(false, 0xFFB0577F, false, farR), L(false, 0xFF793F73, false, midR), L(true, 0xFF2E1B3F, false, peak)),
                pines, 0xFF170E24.toInt(), orb = floatArrayOf(0.30f, 0.52f, 0.08f), orbColor = 0xFFFFE0A8.toInt()),
            Scene("Éjszaka", sky(0xFF04060E, 0xFF101B3C, 0xFF24396B),
                listOf(L(false, 0xFF2B3F73, false, farR), L(false, 0xFF1B2A55, false, midR), L(true, 0xFF0A1020, false, peak)),
                pines, 0xFF050812.toInt(), stars = true, orb = floatArrayOf(0.20f, 0.20f, 0.04f), orbColor = 0xFFEFF3FF.toInt()),
            Scene("Óceán", sky(0xFF021A29, 0xFF1D7A8C, 0xFF9AD9D2),
                listOf(
                    L(false, 0xFF2A93A1, true, "0,0.60 0.5,0.585 1,0.60"),
                    L(false, 0xFF1B7186, true, "0,0.68 0.15,0.64 0.3,0.69 0.45,0.65 0.6,0.70 0.75,0.66 0.9,0.70 1,0.67"),
                    L(true, 0xFF0F4F66, true, "0,0.80 0.2,0.74 0.4,0.80 0.6,0.75 0.8,0.81 1,0.76"),
                    L(true, 0xFF083548, true, "0,0.92 0.25,0.87 0.5,0.92 0.75,0.88 1,0.93")
                ), orb = floatArrayOf(0.50f, 0.56f, 0.07f), orbColor = 0xFFFFF1C9.toInt()),
            Scene("Sivatag", sky(0xFF3B2347, 0xFFE0735A, 0xFFFFD08A),
                listOf(
                    L(false, 0xFFD9895A, true, "0,0.62 0.25,0.56 0.5,0.63 0.75,0.55 1,0.62"),
                    L(false, 0xFFB8643F, true, "0,0.72 0.3,0.64 0.55,0.72 0.8,0.66 1,0.72"),
                    L(true, 0xFF7D3B2D, true, "0,0.84 0.2,0.74 0.4,0.62 0.54,0.44 0.62,0.30 0.74,0.46 0.9,0.66 1,0.72")
                ), orb = floatArrayOf(0.28f, 0.50f, 0.08f), orbColor = 0xFFFFF0C8.toInt()),
            Scene("Erdő", sky(0xFF0E2A1D, 0xFF3F7D4E, 0xFFBFE3B4),
                listOf(
                    Layer(false, 0xFF5E9A6B.toInt(), false, zig(0.62f, 0.06f, 44)),
                    Layer(false, 0xFF2F6A43.toInt(), false, zig(0.72f, 0.07f, 36)),
                    L(true, 0xFF133823, true, "0,0.88 0.3,0.82 0.6,0.86 1,0.82")
                ),
                listOf(
                    floatArrayOf(0.24f, 0.95f, 0.55f), floatArrayOf(0.74f, 0.96f, 0.62f), floatArrayOf(0.06f, 0.97f, 0.40f),
                    floatArrayOf(0.92f, 0.97f, 0.42f), floatArrayOf(0.15f, 0.98f, 0.30f), floatArrayOf(0.84f, 0.98f, 0.28f)
                ), 0xFF0B2417.toInt())
        )
    }

    private val scenes: List<Scene> = buildScenes()

    inner class SceneView(private val front: Boolean) : View(this@MainActivity) {
        var scene: Scene? = null
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()

        override fun onDraw(c: Canvas) {
            val s = scene ?: return
            val w = width.toFloat(); val h = height.toFloat()
            if (!front) {
                if (s.stars) for (i in 0 until 110) {
                    val x = ((i * 7919) % 997) / 997f
                    val y = ((i * 6007) % 991) / 991f * 0.55f
                    p.color = Color.WHITE; p.alpha = 70 + (i * 53) % 170
                    c.drawCircle(x * w, y * h, dp(1) * (0.5f + (i % 3) * 0.35f), p)
                }
                s.orb?.let { o ->
                    val cx = o[0] * w; val cy = o[1] * h; val r = o[2] * h
                    p.color = s.orbColor; p.alpha = 35; c.drawCircle(cx, cy, r * 2.4f, p)
                    p.color = s.orbColor; p.alpha = 80; c.drawCircle(cx, cy, r * 1.6f, p)
                    p.color = s.orbColor; p.alpha = 255; c.drawCircle(cx, cy, r, p)
                }
            }
            for (l in s.layers) if (l.front == front) {
                p.color = l.color
                c.drawPath(layerPath(l, w, h), p)
            }
            if (front) {
                p.color = s.treeColor
                for (t in s.trees) pine(c, t[0] * w, t[1] * h, t[2] * h)
            }
        }

        private fun layerPath(l: Layer, w: Float, h: Float): Path {
            val n = l.pts.size / 2
            fun x(i: Int) = l.pts[i * 2] * w
            fun y(i: Int) = l.pts[i * 2 + 1] * h
            val pa = Path()
            pa.moveTo(x(0), h); pa.lineTo(x(0), y(0))
            if (l.smooth) {
                for (i in 1 until n - 1) pa.quadTo(x(i), y(i), (x(i) + x(i + 1)) / 2, (y(i) + y(i + 1)) / 2)
                pa.lineTo(x(n - 1), y(n - 1))
            } else {
                for (i in 1 until n) pa.lineTo(x(i), y(i))
            }
            pa.lineTo(x(n - 1), h); pa.close()
            return pa
        }

        private fun pine(c: Canvas, cx: Float, base: Float, h: Float) {
            val w = h * 0.36f
            c.drawRect(cx - w * 0.06f, base - h * 0.12f, cx + w * 0.06f, base, p)
            for (k in 0 until 4) {
                val top = base - h + k * h * 0.2f
                val bot = top + h * 0.36f
                val half = w * (0.45f + 0.18f * k)
                path.reset(); path.moveTo(cx, top); path.lineTo(cx + half, bot); path.lineTo(cx - half, bot); path.close()
                c.drawPath(path, p)
            }
        }
    }

    // ---------- Állapot ----------
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var weather: TextView
    private lateinit var dateView: TextView
    private lateinit var root: FrameLayout
    private lateinit var appRow: LinearLayout
    private lateinit var sceneBack: SceneView
    private lateinit var sceneFront: SceneView
    private lateinit var avatarImg: ImageView
    private var lastAppId = View.NO_ID
    private val prefs by lazy { getSharedPreferences("recent", MODE_PRIVATE) }
    private val dateFmt = SimpleDateFormat("EEEE, MMMM d.", Locale("hu", "HU"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val screenH = resources.displayMetrics.heightPixels
        root = FrameLayout(this)
        sceneBack = SceneView(false)
        sceneFront = SceneView(true)

        // 1) hátsó réteg (ég + távoli hegyek)  2) óra  3) elülső réteg (közeli hegy, fák)  4) UI
        root.addView(sceneBack, FrameLayout.LayoutParams(-1, -1))

        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"
            setTextColor(0xF2FFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_PX, screenH * 0.26f)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)   // félkövér
            includeFontPadding = false
            setShadowLayer(dp(8).toFloat(), 0f, dp(3).toFloat(), 0x55000000)
        }
        root.addView(clock, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = (screenH * 0.14f).toInt()
        })
        root.addView(sceneFront, FrameLayout.LayoutParams(-1, -1))
        applyWallpaper()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            setPadding(dp(48), dp(32), dp(48), dp(24))
        }
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        // egy sor: "Hétfő, október 26.  ·  Derült 8°"
        dateView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 18f; setSingleLine()
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        weather = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 18f; setSingleLine()
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val dateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(dateView); addView(weather)
        }
        col.addView(dateRow, LinearLayout.LayoutParams(-1, -2))
        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))

        col.addView(TextView(this).apply {
            text = "Appok"; setTextColor(0xE6FFFFFF.toInt()); textSize = 16f
            setPadding(dp(16), dp(8), 0, dp(4))
        })

        // üveg "polc" az appok mögött
        appRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; clipChildren = false
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; isFillViewport = true
            clipChildren = false; clipToPadding = false
            addView(appRow)
        }
        val dock = FrameLayout(this).apply {
            background = glass(30)
            clipChildren = false; clipToPadding = false
            setPadding(dp(16), dp(12), dp(16), dp(12))
            addView(scroller, FrameLayout.LayoutParams(-1, -2))
        }
        col.addView(dock, LinearLayout.LayoutParams(-1, -2))

        // bal felső sarok: profilkép (kör)
        val avatarBtn = roundButton(R.drawable.ic_person, 44, "Fiók") { accountDialog() }
        avatarImg = avatarBtn.getChildAt(0) as ImageView
        avatarImg.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) { outline.setOval(0, 0, view.width, view.height) }
        }
        avatarImg.clipToOutline = true
        updateAvatar()
        root.addView(avatarBtn, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START).apply {
            setMargins(dp(40), dp(24), 0, 0)
        })

        // jobb felső sarok: háttérválasztó + beállítások (kör alakú üveggombok)
        val wallBtn = roundButton(R.drawable.ic_wallpaper, 48, "Háttérkép") { wallpaperDialog() }
        val setBtn = roundButton(R.drawable.ic_settings, 40, "Beállítások") {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        wallBtn.nextFocusRightId = setBtn.id
        wallBtn.nextFocusLeftId = avatarBtn.id
        setBtn.nextFocusLeftId = wallBtn.id
        avatarBtn.nextFocusRightId = wallBtn.id
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            addView(wallBtn, LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(dp(8), 0, dp(8), 0) })
            addView(setBtn, LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(8), 0, dp(8), 0) })
        }
        root.addView(topBar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(24), dp(40), 0)
        })

        buildAppRow(wallBtn)
        setContentView(root)
        appRow.getChildAt(0)?.requestFocus()
        tickDate()
        refreshWeather()
    }

    private fun tickDate() {
        val s = dateFmt.format(Date())
        dateView.text = Character.toUpperCase(s[0]).toString() + s.substring(1)
        handler.postDelayed({ tickDate() }, 60_000L)
    }

    // ---------- Üveg (liquid glass) segédek ----------
    private fun glass(radiusDp: Int, strong: Boolean = false, circle: Boolean = false): Drawable {
        fun make(init: GradientDrawable.() -> Unit) = GradientDrawable().apply {
            if (circle) shape = GradientDrawable.OVAL else cornerRadius = dp(radiusDp).toFloat()
            init()
        }
        val base = make {
            setColor(Color.argb(if (strong) 0x66 else 0x2C, 255, 255, 255))
            setStroke(dp(1).coerceAtLeast(1), Color.argb(if (strong) 0xC0 else 0x80, 255, 255, 255))
        }
        // felső fénycsík + alsó visszatükröződés: ettől lesz "üveges"
        val sheen = make {
            orientation = GradientDrawable.Orientation.TOP_BOTTOM
            colors = intArrayOf(0x66FFFFFF, 0x10FFFFFF, 0x00FFFFFF, 0x26FFFFFF)
        }
        return LayerDrawable(arrayOf(base, sheen))
    }

    private fun roundButton(iconRes: Int, sizeDp: Int, desc: String, click: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val normal = glass(0, strong = false, circle = true)
        val focused = glass(0, strong = true, circle = true)
        f.id = View.generateViewId()
        f.background = normal
        f.contentDescription = desc
        val pad = dp(sizeDp / 4)
        f.addView(ImageView(this).apply {
            setImageResource(iconRes); scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(pad, pad, pad, pad)
        }, FrameLayout.LayoutParams(-1, -1))
        f.isFocusable = true; f.isClickable = true
        f.setOnClickListener { click() }
        f.setOnFocusChangeListener { v, focus ->
            v.background = if (focus) focused else normal
            val s = if (focus) 1.15f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(140).start()
            if (focus && lastAppId != View.NO_ID) v.nextFocusDownId = lastAppId
        }
        return f
    }

    // App csempe: csak a saját ikon (keret nélkül), fókuszra kinagyodik
    private fun appTile(icon: Drawable?, label: String, upId: Int, click: () -> Unit): View {
        val v: View = if (icon != null) {
            ImageView(this).apply {
                setImageDrawable(icon); scaleType = ImageView.ScaleType.FIT_CENTER
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat())
                    }
                }
                clipToOutline = true
            }
        } else {
            TextView(this).apply {
                text = label; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
                maxLines = 2; setPadding(dp(10), dp(6), dp(10), dp(6))
                background = glass(14)
            }
        }
        v.id = View.generateViewId()
        v.nextFocusUpId = upId
        v.isFocusable = true; v.isClickable = true
        v.alpha = 0.92f
        v.setOnClickListener { click() }
        v.setOnFocusChangeListener { view, focus ->
            val s = if (focus) 1.15f else 1f
            view.animate().scaleX(s).scaleY(s).alpha(if (focus) 1f else 0.92f)
                .translationZ(if (focus) dp(8).toFloat() else 0f).setDuration(140).start()
            if (focus) lastAppId = view.id
        }
        v.layoutParams = LinearLayout.LayoutParams(dp(160), dp(90)).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) }
        return v
    }

    // ---------- Háttér ----------
    private val wpFile get() = File(filesDir, "wallpaper.jpg")
    private val avatarFile get() = File(filesDir, "avatar.jpg")

    private fun applyWallpaper() {
        val p = prefs.getString("wp", "preset:0") ?: "preset:0"
        if (p == "file" && wpFile.exists()) {
            val bmp = BitmapFactory.decodeFile(wpFile.path)
            if (bmp != null) {
                root.background = BitmapDrawable(resources, bmp)
                sceneBack.visibility = View.GONE; sceneFront.visibility = View.GONE
                return
            }
        }
        val idx = p.removePrefix("preset:").toIntOrNull()?.coerceIn(0, scenes.size - 1) ?: 0
        val s = scenes[idx]
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, s.sky)
        sceneBack.scene = s; sceneFront.scene = s
        sceneBack.visibility = View.VISIBLE; sceneFront.visibility = View.VISIBLE
        sceneBack.invalidate(); sceneFront.invalidate()
    }

    private fun wallpaperDialog() {
        val items = scenes.map { it.name }.toMutableList()
        items.add("Saját kép (fájlból)"); items.add("Kép letöltése URL-ből")
        AlertDialog.Builder(this).setTitle("Háttérkép").setItems(items.toTypedArray()) { _, i ->
            when {
                i < scenes.size -> { prefs.edit().putString("wp", "preset:$i").apply(); applyWallpaper() }
                i == scenes.size -> pickFile(42)
                else -> urlDialog(42)
            }
        }.show()
    }

    // ---------- Profilkép ----------
    private fun updateAvatar() {
        if (avatarFile.exists()) {
            val bmp = BitmapFactory.decodeFile(avatarFile.path)
            if (bmp != null) {
                avatarImg.setPadding(0, 0, 0, 0)
                avatarImg.scaleType = ImageView.ScaleType.CENTER_CROP
                avatarImg.setImageBitmap(bmp)
                return
            }
        }
        val pad = dp(11)
        avatarImg.setPadding(pad, pad, pad, pad)
        avatarImg.scaleType = ImageView.ScaleType.FIT_CENTER
        avatarImg.setImageResource(R.drawable.ic_person)
    }

    private fun accountDialog() {
        val items = arrayOf("Profilkép: saját kép (fájlból)", "Profilkép: letöltés URL-ből", "Profilkép törlése", "Fiókok megnyitása")
        AlertDialog.Builder(this).setTitle("Fiók").setItems(items) { _, i ->
            when (i) {
                0 -> pickFile(43)
                1 -> urlDialog(43)
                2 -> { avatarFile.delete(); updateAvatar() }
                else -> try {
                    startActivity(Intent(Settings.ACTION_SYNC_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    Toast.makeText(this, "A fiókbeállítás nem nyitható meg", Toast.LENGTH_LONG).show()
                }
            }
        }.show()
    }

    // ---------- Képbetöltés (háttér: 42, profilkép: 43) ----------
    private fun pickFile(code: Int) {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), code)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Ezen a TV-n nincs fájlválasztó. Használd az URL-es opciót.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == 42 || requestCode == 43) importImage(requestCode) { contentResolver.openInputStream(uri)!! }
    }

    private fun urlDialog(target: Int) {
        val et = EditText(this).apply { hint = "https://... .jpg"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Kép URL").setView(et)
            .setPositiveButton("Letöltés") { _, _ ->
                val u = et.text.toString().trim()
                importImage(target) { URL(u).openStream() }
            }.setNegativeButton("Mégse", null).show()
    }

    private fun importImage(target: Int, open: () -> java.io.InputStream) {
        thread {
            try {
                open().use { saveImage(it, if (target == 42) wpFile else avatarFile, if (target == 42) 1920 else 512) }
                runOnUiThread {
                    if (target == 42) { prefs.edit().putString("wp", "file").apply(); applyWallpaper() } else updateAvatar()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Nem sikerült a kép betöltése", Toast.LENGTH_LONG).show() }
            }
        }
    }

    // kicsinyítve menti, hogy a régi TV-n/stickben se fogyjon el a memória
    private fun saveImage(input: java.io.InputStream, out: File, maxW: Int) {
        val bytes = input.readBytes()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxW) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw IllegalStateException("bad image")
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
    }

    // ---------- Appsor ----------
    private fun buildAppRow(upTarget: View) {
        for (a in apps) appRow.addView(appTile(iconFor(a), a.label, upTarget.id) { launch(a) })
        lastAppId = appRow.getChildAt(0)?.id ?: View.NO_ID
    }

    private fun intentFor(a: AppDef): Intent? {
        val pm = packageManager
        for (p in a.pkgs) (pm.getLeanbackLaunchIntentForPackage(p) ?: pm.getLaunchIntentForPackage(p))?.let { return it }
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val main = Intent(Intent.ACTION_MAIN).addCategory(cat)
            pm.queryIntentActivities(main, 0).firstOrNull { it.loadLabel(pm).toString().contains(a.key, true) }?.let {
                return Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setClassName(it.activityInfo.packageName, it.activityInfo.name)
            }
        }
        return null
    }

    private fun iconFor(a: AppDef): Drawable? {
        a.logo?.let { return getDrawable(it) }
        val i = intentFor(a) ?: return null
        val info = packageManager.resolveActivity(i, 0)?.activityInfo ?: return null
        return info.loadBanner(packageManager) ?: info.loadIcon(packageManager)
    }

    private fun launch(a: AppDef) {
        val i = intentFor(a)
        if (i == null) { Toast.makeText(this, "${a.label} nincs telepítve", Toast.LENGTH_LONG).show(); return }
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- Időjárás (Open-Meteo, API kulcs nélkül) ----------
    private fun refreshWeather() {
        thread {
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current=temperature_2m,weather_code"
                val c = JSONObject(URL(url).readText()).getJSONObject("current")
                val t = Math.round(c.getDouble("temperature_2m"))
                val txt = when (c.getInt("weather_code")) {
                    0 -> "Derült"; 1, 2 -> "Többnyire derült"; 3 -> "Borult"; 45, 48 -> "Köd"
                    in 51..67 -> "Eső"; in 71..77 -> "Hó"; in 80..82 -> "Zápor"; else -> "Zivatar"
                }
                runOnUiThread { weather.text = "  ·  $txt $t°" }
            } catch (e: Exception) { /* offline: marad a régi érték */ }
        }
        handler.postDelayed({ refreshWeather() }, 30 * 60 * 1000L)
    }
}
