package hu.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {

    // ---- BEÁLLÍTÁSOK: ide írd át a városod koordinátáit ----
    private val LAT = 47.9025   // Eger
    private val LON = 20.3772
    // --------------------------------------------------------

    // logo: ha meg van adva, mindig ezt a saját logót használja (nem a telepített app ikonját)
    data class AppDef(val key: String, val label: String, val pkgs: List<String>, val logo: Int? = null)

    private val apps = listOf(
        AppDef("Netflix", "Netflix", listOf("com.netflix.ninja")),
        AppDef("YouTube", "YouTube", listOf("com.google.android.youtube.tv")),
        AppDef("Apple Music", "Apple Music", listOf("com.apple.android.music"), R.drawable.logo_apple_music),
        AppDef("Apple TV", "Apple TV", listOf("com.apple.atve.androidtv.appletv"), R.drawable.logo_apple_tv),
        AppDef("Disney", "Disney+", listOf("com.disney.disneyplus")),
        AppDef("SkyShowtime", "SkyShowtime", listOf())
    )

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var weather: TextView
    private lateinit var root: FrameLayout
    private lateinit var appRow: LinearLayout
    private var lastAppId = View.NO_ID
    private val prefs by lazy { getSharedPreferences("recent", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        applyWallpaper()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            setPadding(dp(48), dp(32), dp(48), dp(24))
        }
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        val date = TextClock(this).apply {
            format24Hour = "yyyy. MMMM d., EEEE"; format12Hour = "yyyy. MMMM d., EEEE"
            setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        weather = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"
            setTextColor(0xE6FFFFFF.toInt()); textSize = 120f; gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        }
        col.addView(date, LinearLayout.LayoutParams(-1, -2))
        col.addView(weather, LinearLayout.LayoutParams(-1, -2))
        col.addView(clock, LinearLayout.LayoutParams(-1, 0, 1f))

        col.addView(TextView(this).apply {
            text = "Appok"; setTextColor(0xE6FFFFFF.toInt()); textSize = 16f
            setPadding(dp(16), dp(8), 0, dp(4))
        })

        // üveg "polc" az appok mögött
        appRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; clipChildren = false
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; isFillViewport = true
            clipChildren = false; clipToPadding = false
            addView(appRow)
        }
        val dock = FrameLayout(this).apply {
            background = glass(30)
            clipChildren = false; clipToPadding = false
            setPadding(dp(16), dp(12), dp(16), dp(12))
            addView(scroller, FrameLayout.LayoutParams(-1, -2))
        }
        col.addView(dock, LinearLayout.LayoutParams(-1, -2))

        // jobb felső sarok: háttérválasztó + beállítások (kör alakú üveggombok)
        val wallBtn = roundButton(R.drawable.ic_wallpaper, 48, "Háttérkép") { wallpaperDialog() }
        val setBtn = roundButton(R.drawable.ic_settings, 40, "Beállítások") {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        wallBtn.nextFocusRightId = setBtn.id
        setBtn.nextFocusLeftId = wallBtn.id
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            addView(wallBtn); addView(setBtn)
        }
        root.addView(topBar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(24), dp(40), 0)
        })

        buildAppRow(wallBtn)
        setContentView(root)
        appRow.getChildAt(0)?.requestFocus()
        refreshWeather()
    }

    // ---------- Üveg (liquid glass) segédek ----------
    private fun glass(radiusDp: Int, strong: Boolean = false, circle: Boolean = false): Drawable {
        fun make(init: GradientDrawable.() -> Unit) = GradientDrawable().apply {
            if (circle) shape = GradientDrawable.OVAL else cornerRadius = dp(radiusDp).toFloat()
            init()
        }
        val base = make {
            setColor(Color.argb(if (strong) 0x55 else 0x26, 255, 255, 255))
            setStroke(dp(1).coerceAtLeast(1), Color.argb(if (strong) 0xB0 else 0x66, 255, 255, 255))
        }
        // felső fénycsík, ettől lesz "üveges"
        val sheen = make {
            orientation = GradientDrawable.Orientation.TOP_BOTTOM
            colors = intArrayOf(0x44FFFFFF, 0x00FFFFFF, 0x14FFFFFF)
        }
        return LayerDrawable(arrayOf(base, sheen))
    }

    private fun roundButton(iconRes: Int, sizeDp: Int, desc: String, click: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val normal = glass(0, strong = false, circle = true)
        val focused = glass(0, strong = true, circle = true)
        f.id = View.generateViewId()
        f.background = normal
        f.contentDescription = desc
        val pad = dp(sizeDp / 4)
        f.addView(ImageView(this).apply {
            setImageResource(iconRes); scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(pad, pad, pad, pad)
        }, FrameLayout.LayoutParams(-1, -1))
        f.isFocusable = true; f.isClickable = true
        f.setOnClickListener { click() }
        f.setOnFocusChangeListener { v, focus ->
            v.background = if (focus) focused else normal
            val s = if (focus) 1.15f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(140).start()
            if (focus && lastAppId != View.NO_ID) v.nextFocusDownId = lastAppId
        }
        f.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply { setMargins(dp(8), 0, dp(8), 0) }
        return f
    }

    // App csempe: csak a saját ikon (keret nélkül), fókuszra kinagyodik
    private fun appTile(icon: Drawable?, label: String, upId: Int, click: () -> Unit): View {
        val v: View = if (icon != null) {
            ImageView(this).apply {
                setImageDrawable(icon); scaleType = ImageView.ScaleType.FIT_CENTER
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat())
                    }
                }
                clipToOutline = true
            }
        } else {
            // ha az app nincs telepítve: üveg csempe a névvel
            TextView(this).apply {
                text = label; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
                maxLines = 2; setPadding(dp(10), dp(6), dp(10), dp(6))
                background = glass(14)
            }
        }
        v.id = View.generateViewId()
        v.nextFocusUpId = upId
        v.isFocusable = true; v.isClickable = true
        v.alpha = 0.92f
        v.setOnClickListener { click() }
        v.setOnFocusChangeListener { view, focus ->
            val s = if (focus) 1.15f else 1f
            view.animate().scaleX(s).scaleY(s).alpha(if (focus) 1f else 0.92f)
                .translationZ(if (focus) dp(8).toFloat() else 0f).setDuration(140).start()
            if (focus) lastAppId = view.id
        }
        v.layoutParams = LinearLayout.LayoutParams(dp(160), dp(90)).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) }
        return v
    }

    // ---------- Háttérkép ----------
    private val presets = listOf(
        "Naplemente" to intArrayOf(0xFF2A1B3D.toInt(), 0xFF8B3A62.toInt(), 0xFF1B1B2F.toInt()),
        "Éjszaka" to intArrayOf(0xFF05070F.toInt(), 0xFF1B2A4E.toInt(), 0xFF05070F.toInt()),
        "Óceán" to intArrayOf(0xFF03253A.toInt(), 0xFF1D7A8C.toInt(), 0xFF021A29.toInt()),
        "Erdő" to intArrayOf(0xFF0E2A1D.toInt(), 0xFF3F7D4E.toInt(), 0xFF0A1A12.toInt())
    )
    private val wpFile get() = File(filesDir, "wallpaper.jpg")

    private fun applyWallpaper() {
        val p = prefs.getString("wp", "preset:0") ?: "preset:0"
        if (p == "file" && wpFile.exists()) {
            val bmp = BitmapFactory.decodeFile(wpFile.path)
            if (bmp != null) { root.background = BitmapDrawable(resources, bmp); return }
        }
        val idx = p.removePrefix("preset:").toIntOrNull()?.coerceIn(0, presets.size - 1) ?: 0
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, presets[idx].second)
    }

    private fun wallpaperDialog() {
        val items = presets.map { it.first }.toMutableList()
        items.add("Saját kép (fájlból)"); items.add("Kép letöltése URL-ből")
        AlertDialog.Builder(this).setTitle("Háttérkép").setItems(items.toTypedArray()) { _, i ->
            when {
                i < presets.size -> { prefs.edit().putString("wp", "preset:$i").apply(); applyWallpaper() }
                i == presets.size -> pickFile()
                else -> urlDialog()
            }
        }.show()
    }

    private fun pickFile() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 42)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Ezen a TV-n nincs fájlválasztó. Használd az URL-es opciót.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode != 42 || resultCode != RESULT_OK) return
        thread {
            try { contentResolver.openInputStream(uri)!!.use { saveWallpaper(it) } }
            catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Nem sikerült a kép betöltése", Toast.LENGTH_LONG).show() } }
        }
    }

    private fun urlDialog() {
        val et = EditText(this).apply { hint = "https://... .jpg"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Kép URL").setView(et)
            .setPositiveButton("Letöltés") { _, _ ->
                val u = et.text.toString().trim()
                thread {
                    try { URL(u).openStream().use { saveWallpaper(it) } }
                    catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Nem sikerült a letöltés", Toast.LENGTH_LONG).show() } }
                }
            }.setNegativeButton("Mégse", null).show()
    }

    // 1920 px-re kicsinyítve menti, hogy a régi TV-n/stickben se fogyjon el a memória
    private fun saveWallpaper(input: java.io.InputStream) {
        val bytes = input.readBytes()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 1920) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw IllegalStateException("bad image")
        wpFile.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
        prefs.edit().putString("wp", "file").apply()
        runOnUiThread { applyWallpaper() }
    }

    // ---------- Appsor ----------
    private fun buildAppRow(upTarget: View) {
        for (a in apps) appRow.addView(appTile(iconFor(a), a.label, upTarget.id) { launch(a) })
        lastAppId = appRow.getChildAt(0)?.id ?: View.NO_ID
    }

    private fun intentFor(a: AppDef): Intent? {
        val pm = packageManager
        for (p in a.pkgs) (pm.getLeanbackLaunchIntentForPackage(p) ?: pm.getLaunchIntentForPackage(p))?.let { return it }
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val main = Intent(Intent.ACTION_MAIN).addCategory(cat)
            pm.queryIntentActivities(main, 0).firstOrNull { it.loadLabel(pm).toString().contains(a.key, true) }?.let {
                return Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setClassName(it.activityInfo.packageName, it.activityInfo.name)
            }
        }
        return null
    }

    private fun iconFor(a: AppDef): Drawable? {
        a.logo?.let { return getDrawable(it) }
        val i = intentFor(a) ?: return null
        val info = packageManager.resolveActivity(i, 0)?.activityInfo ?: return null
        return info.loadBanner(packageManager) ?: info.loadIcon(packageManager)
    }

    private fun launch(a: AppDef) {
        val i = intentFor(a)
        if (i == null) { Toast.makeText(this, "${a.label} nincs telepítve", Toast.LENGTH_LONG).show(); return }
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- Időjárás (Open-Meteo, API kulcs nélkül) ----------
    private fun refreshWeather() {
        thread {
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current=temperature_2m,weather_code"
                val c = JSONObject(URL(url).readText()).getJSONObject("current")
                val t = Math.round(c.getDouble("temperature_2m"))
                val txt = when (c.getInt("weather_code")) {
                    0 -> "Derült"; 1, 2 -> "Többnyire derült"; 3 -> "Borult"; 45, 48 -> "Köd"
                    in 51..67 -> "Eső"; in 71..77 -> "Hó"; in 80..82 -> "Zápor"; else -> "Zivatar"
                }
                runOnUiThread { weather.text = "Eger · $t° $txt" }
            } catch (e: Exception) { /* offline: marad a régi érték */ }
        }
        handler.postDelayed({ refreshWeather() }, 30 * 60 * 1000L)
    }
}
