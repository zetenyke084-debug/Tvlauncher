package hu.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {

    // ---- BEÁLLÍTÁSOK: ide írd át a városod koordinátáit ----
    private val LAT = 47.9025   // Eger
    private val LON = 20.3772
    // --------------------------------------------------------

    data class AppDef(val key: String, val label: String, val pkgs: List<String>, val color: Int)

    private val apps = listOf(
        AppDef("Netflix", "Netflix", listOf("com.netflix.ninja"), 0xFFE50914.toInt()),
        AppDef("YouTube", "YouTube", listOf("com.google.android.youtube.tv"), 0xFFCC0000.toInt()),
        AppDef("Apple Music", "Apple Music", listOf("com.apple.android.music"), 0xFFFA243C.toInt()),
        AppDef("Apple TV", "Apple TV", listOf("com.apple.atve.androidtv.appletv"), 0xFF1C1C1E.toInt()),
        AppDef("Disney", "Disney+", listOf("com.disney.disneyplus"), 0xFF113CCF.toInt()),
        // Az RTL+ csomagnevét név alapján keresi meg (ha nem találja, add meg ide)
        AppDef("RTL", "RTL+", listOf(), 0xFF0A2A5E.toInt())
    )

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var weather: TextView
    private lateinit var recentRow: LinearLayout
    private lateinit var appRow: LinearLayout
    private val prefs by lazy { getSharedPreferences("recent", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF2A1B3D.toInt(), 0xFF8B3A62.toInt(), 0xFF1B1B2F.toInt())
            )
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(48), dp(32), dp(48), dp(24)) }
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        val date = TextClock(this).apply {
            format24Hour = "yyyy. MMMM d., EEEE"; format12Hour = "yyyy. MMMM d., EEEE"
            setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
        }
        weather = TextView(this).apply { setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER }
        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"
            setTextColor(0xCCFFFFFF.toInt()); textSize = 120f; gravity = Gravity.CENTER
        }
        col.addView(date, LinearLayout.LayoutParams(-1, -2))
        col.addView(weather, LinearLayout.LayoutParams(-1, -2))
        col.addView(clock, LinearLayout.LayoutParams(-1, 0, 1f))

        col.addView(label("Tovább nézem"))
        recentRow = row(); col.addView(scroller(recentRow))
        col.addView(label("Appok"))
        appRow = row(); col.addView(scroller(appRow))

        buildAppRow()
        setContentView(root)
        appRow.getChildAt(0)?.requestFocus()
        refreshWeather()
    }

    override fun onResume() { super.onResume(); buildRecent() }

    // ---------- UI segédek ----------
    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 16f; setPadding(dp(16), dp(8), 0, 0) }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false; setPadding(dp(8), dp(8), dp(8), dp(8)) }
    private fun scroller(r: LinearLayout) = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false; clipChildren = false; clipToPadding = false; addView(r)
    }

    private fun tile(w: Int, h: Int, color: Int, icon: Drawable?, text: String?, longClick: (() -> Unit)? = null, click: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val bg = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(color) }
        f.background = bg
        if (icon != null) {
            f.addView(ImageView(this).apply {
                setImageDrawable(icon); scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }, FrameLayout.LayoutParams(-1, -1))
        } else {
            f.addView(TextView(this).apply {
                this.text = text; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
                maxLines = 4; setPadding(dp(10), dp(6), dp(10), dp(6))
            }, FrameLayout.LayoutParams(-1, -1))
        }
        f.isFocusable = true; f.isClickable = true
        f.setOnClickListener { click() }
        if (longClick != null) f.setOnLongClickListener { longClick(); true }
        f.setOnFocusChangeListener { v, focus ->
            val s = if (focus) 1.12f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            bg.setStroke(if (focus) dp(3) else 0, Color.WHITE)
        }
        f.layoutParams = LinearLayout.LayoutParams(dp(w), dp(h)).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) }
        return f
    }

    // ---------- Appsor ----------
    private fun buildAppRow() {
        appRow.addView(tile(110, 90, 0xFF3A3A4A.toInt(), null, "HDMI") { hdmi() })
        for (a in apps) appRow.addView(tile(160, 90, a.color, iconFor(a), a.label) { launch(a) })
        appRow.addView(tile(90, 90, 0xFF3A3A4A.toInt(), null, "⚙") {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
    }

    private fun intentFor(a: AppDef): Intent? {
        val pm = packageManager
        for (p in a.pkgs) (pm.getLeanbackLaunchIntentForPackage(p) ?: pm.getLaunchIntentForPackage(p))?.let { return it }
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val main = Intent(Intent.ACTION_MAIN).addCategory(cat)
            pm.queryIntentActivities(main, 0).firstOrNull { it.loadLabel(pm).toString().contains(a.key, true) }?.let {
                return Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setClassName(it.activityInfo.packageName, it.activityInfo.name)
            }
        }
        return null
    }

    private fun iconFor(a: AppDef): Drawable? {
        val i = intentFor(a) ?: return null
        val info = packageManager.resolveActivity(i, 0)?.activityInfo ?: return null
        return info.loadBanner(packageManager) ?: info.loadIcon(packageManager)
    }

    private fun launch(a: AppDef) {
        val i = intentFor(a)
        if (i == null) { Toast.makeText(this, "${a.label} nincs telepítve", Toast.LENGTH_LONG).show(); return }
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- Tovább nézem (saját sorozatlista) ----------
    private fun loadSeries(): MutableList<JSONObject> {
        val arr = org.json.JSONArray(prefs.getString("series", "[]"))
        return MutableList(arr.length()) { arr.getJSONObject(it) }
    }

    private fun saveSeries(l: List<JSONObject>) {
        prefs.edit().putString("series", org.json.JSONArray(l).toString()).apply()
    }

    private fun buildRecent() {
        recentRow.removeAllViews()
        recentRow.addView(tile(90, 135, 0xFF3A3A4A.toInt(), null, "+") { seriesDialog(null) })
        loadSeries().forEachIndexed { i, s ->
            val a = apps.firstOrNull { it.key == s.optString("app") } ?: return@forEachIndexed
            val ep = s.optString("ep")
            val txt = s.optString("title") + (if (ep.isNotEmpty()) "\n$ep" else "") + "\n" + a.label
            recentRow.addView(tile(240, 135, a.color, null, txt, longClick = { seriesDialog(i) }) { launch(a) })
        }
    }

    private fun seriesDialog(idx: Int?) {
        val list = loadSeries()
        val cur = idx?.let { list[it] }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(8), dp(24), 0) }
        val title = EditText(this).apply { hint = "Sorozat címe"; setText(cur?.optString("title") ?: ""); setSingleLine() }
        val ep = EditText(this).apply { hint = "Hol tartasz? (pl. 2. évad 5. rész)"; setText(cur?.optString("ep") ?: ""); setSingleLine() }
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, apps.map { it.label })
            setSelection(apps.indexOfFirst { it.key == cur?.optString("app") }.coerceAtLeast(0))
        }
        box.addView(title); box.addView(ep); box.addView(sp)
        AlertDialog.Builder(this)
            .setTitle(if (cur == null) "Új sorozat" else "Sorozat szerkesztése")
            .setView(box)
            .setPositiveButton("Mentés") { _, _ ->
                val t = title.text.toString().trim()
                if (t.isEmpty()) return@setPositiveButton
                val o = JSONObject().put("title", t).put("ep", ep.text.toString().trim())
                    .put("app", apps[sp.selectedItemPosition].key)
                if (idx == null) list.add(0, o) else list[idx] = o
                saveSeries(list); buildRecent()
            }
            .setNegativeButton("Mégse", null)
            .apply { if (idx != null) setNeutralButton("Törlés") { _, _ -> list.removeAt(idx); saveSeries(list); buildRecent() } }
            .show()
    }

    // ---------- HDMI ----------
    private fun hdmi() {
        val tm = getSystemService(TV_INPUT_SERVICE) as TvInputManager
        val ins = tm.tvInputList.filter { it.type == TvInputInfo.TYPE_HDMI }
        if (ins.isEmpty()) {
            Toast.makeText(this, "Ezen az eszközön nincs HDMI-bemenet. A Hisense távirányító Input/Source gombját használd.", Toast.LENGTH_LONG).show()
            return
        }
        val names = ins.map { (it.loadCustomLabel(this) ?: it.loadLabel(this)).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("HDMI bemenet").setItems(names) { _, i ->
            startActivity(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(ins[i].id)))
        }.show()
    }

    // ---------- Időjárás (Open-Meteo, API kulcs nélkül) ----------
    private fun refreshWeather() {
        thread {
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current=temperature_2m,weather_code"
                val c = JSONObject(URL(url).readText()).getJSONObject("current")
                val t = Math.round(c.getDouble("temperature_2m"))
                val txt = when (c.getInt("weather_code")) {
                    0 -> "Derült"; 1, 2 -> "Többnyire derült"; 3 -> "Borult"; 45, 48 -> "Köd"
                    in 51..67 -> "Eső"; in 71..77 -> "Hó"; in 80..82 -> "Zápor"; else -> "Zivatar"
                }
                runOnUiThread { weather.text = "Eger · $t° $txt" }
            } catch (e: Exception) { /* offline: marad a régi érték */ }
        }
        handler.postDelayed({ refreshWeather() }, 30 * 60 * 1000L)
    }
}
